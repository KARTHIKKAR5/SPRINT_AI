// Firebase Configuration
const firebaseConfig = {
  apiKey: "AIzaSyAebfWw48WiJhQgXncY0BZVbAXsvcdsUnY",
  authDomain: "sprint-6ae82.firebaseapp.com",
  projectId: "sprint-6ae82",
  storageBucket: "sprint-6ae82.firebasestorage.app",
  messagingSenderId: "401519186033",
  appId: "1:401519186033:web:47b0ffdfe8326e60804bd0",
  measurementId: "G-W6Y943TZ4V"
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
const auth = firebase.auth();
const db = firebase.firestore();
const storage = firebase.storage();

// API Configuration
const API_CONFIG = {
  defaultUrl: "https://sprint-ai-api.onrender.com",
  endpoints: {
    analyze: "/analyze",
    health: "/health"
  },
  timeout: 120000
};

// Get API URL from storage or use default
const getApiUrl = () => {
  try {
    return JSON.parse(window.localStorage?.getItem('sprintai_api_url') || 'null') || API_CONFIG.defaultUrl;
  } catch {
    return API_CONFIG.defaultUrl;
  }
};

// Set API URL in storage
const setApiUrl = (url) => {
  try {
    window.localStorage?.setItem('sprintai_api_url', JSON.stringify(url));
  } catch {
    // Storage not available, use in-memory fallback
    window.sprintaiApiUrl = url;
  }
};

// Backend Status Hook
const useBackendStatus = () => {
  const [status, setStatus] = useState('checking');
  const [apiUrl, setApiUrlState] = useState(getApiUrl());
  
  const checkStatus = async () => {
    setStatus('checking');
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000);
      
      const response = await fetch(`${apiUrl}${API_CONFIG.endpoints.health}`, {
        method: 'GET',
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      if (response.ok) {
        setStatus('online');
      } else {
        setStatus('offline');
      }
    } catch (error) {
      setStatus('offline');
    }
  };
  
  useEffect(() => {
    checkStatus();
    const interval = setInterval(checkStatus, 30000); // Check every 30 seconds
    return () => clearInterval(interval);
  }, [apiUrl]);
  
  const updateApiUrl = (newUrl) => {
    setApiUrl(newUrl);
    setApiUrlState(newUrl);
    checkStatus();
  };
  
  return { status, apiUrl, updateApiUrl, checkStatus };
};

// React Components
const { useState, useEffect } = React;

// Constants
const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman and Nicobar Islands", "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu", "Delhi", "Jammu and Kashmir", "Ladakh", "Lakshadweep", "Puducherry"
];

const DISTANCES = ["100m", "400m", "1km", "5km"];

const TRAINING_PLANS = {
  "100m": [
    { day: "Monday", warmup: "Jog + stretches", main: "5x60m sprints + squats", cooldown: "Walk + stretch" },
    { day: "Tuesday", warmup: "Dynamic stretches", main: "4x80m tempo + lunges", cooldown: "Foam roll" },
    { day: "Wednesday", warmup: "Light jog", main: "Plyometrics: box jumps, bounds", cooldown: "Stretch" },
    { day: "Thursday", warmup: "Activation drills", main: "6x50m block starts", cooldown: "Cool walk" },
    { day: "Friday", warmup: "Stretches", main: "3x100m at 90% + core", cooldown: "Yoga" },
    { day: "Saturday", warmup: "Warm-up", main: "Hill sprints 8x30m", cooldown: "Ice bath" },
    { day: "Sunday", warmup: "Rest", main: "Light walk 20min", cooldown: "Recovery" }
  ],
  "400m": [
    { day: "Monday", warmup: "2km jog", main: "4x200m at race pace", cooldown: "Stretch" },
    { day: "Tuesday", warmup: "Dynamic", main: "6x100m speed endurance", cooldown: "Cool down" },
    { day: "Wednesday", warmup: "Easy run", main: "Tempo 3x300m", cooldown: "Stretch" },
    { day: "Thursday", warmup: "Drills", main: "8x150m intervals", cooldown: "Walk" },
    { day: "Friday", warmup: "Warm-up", main: "2x400m time trial", cooldown: "Recovery" },
    { day: "Saturday", warmup: "Long run 5km easy", main: "Core circuit", cooldown: "Stretch" },
    { day: "Sunday", warmup: "Rest", main: "Massage/foam roll", cooldown: "Mobility" }
  ],
  "1km": [
    { day: "Monday", warmup: "3km jog", main: "5x400m intervals", cooldown: "Stretch" },
    { day: "Tuesday", warmup: "Warm-up", main: "Tempo run 2km", cooldown: "Cool jog" },
    { day: "Wednesday", warmup: "Easy 4km", main: "Fartlek training", cooldown: "Stretch" },
    { day: "Thursday", warmup: "Drills", main: "6x600m intervals", cooldown: "Walk" },
    { day: "Friday", warmup: "Warm-up", main: "1km time trial", cooldown: "Recovery" },
    { day: "Saturday", warmup: "Long run 8km easy", main: "Hill repeats", cooldown: "Stretch" },
    { day: "Sunday", warmup: "Rest", main: "Cross-training swim", cooldown: "Mobility" }
  ],
  "5km": [
    { day: "Monday", warmup: "4km jog", main: "8x800m intervals", cooldown: "Stretch" },
    { day: "Tuesday", warmup: "Easy 6km", main: "Tempo 3km", cooldown: "Cool down" },
    { day: "Wednesday", warmup: "Recovery 5km", main: "Strides 6x100m", cooldown: "Stretch" },
    { day: "Thursday", warmup: "Warm-up", main: "10x400m intervals", cooldown: "Walk" },
    { day: "Friday", warmup: "Easy 5km", main: "Progression run", cooldown: "Recovery" },
    { day: "Saturday", warmup: "Long run 15km", main: "Core strength", cooldown: "Stretch" },
    { day: "Sunday", warmup: "Rest", main: "Active recovery walk", cooldown: "Yoga" }
  ]
};

const DIET_PLANS = {
  "100m": [
    { time: "6:00 AM", meal: "1 banana + 4 almonds + black coffee" },
    { time: "8:00 AM", meal: "Whey 30g + banana + 3 egg whites" },
    { time: "9:30 AM", meal: "Oats 40g + milk + honey" },
    { time: "12:30 PM", meal: "2 chapati + chicken/paneer + salad" },
    { time: "4:00 PM", meal: "Peanut butter sandwich" },
    { time: "7:30 PM", meal: "Grilled fish/paneer + 2 phulka" },
    { time: "10:00 PM", meal: "Milk + turmeric" }
  ],
  "400m": [
    { time: "6:00 AM", meal: "Banana + dates + green tea" },
    { time: "8:00 AM", meal: "Whey shake + oats + berries" },
    { time: "10:00 AM", meal: "4 egg whites + brown bread" },
    { time: "1:00 PM", meal: "Rice + dal + chicken/soya + vegetables" },
    { time: "4:00 PM", meal: "Protein bar + coconut water" },
    { time: "7:30 PM", meal: "Quinoa + grilled chicken + salad" },
    { time: "10:00 PM", meal: "Casein shake + almonds" }
  ],
  "1km": [
    { time: "6:00 AM", meal: "Warm water + lemon + honey" },
    { time: "8:00 AM", meal: "Poha + peanuts + curd" },
    { time: "10:30 AM", meal: "Fruit salad + nuts" },
    { time: "1:00 PM", meal: "3 chapati + rajma + vegetables + curd" },
    { time: "4:30 PM", meal: "Sprouts salad + buttermilk" },
    { time: "8:00 PM", meal: "Brown rice + fish curry + beans" },
    { time: "10:30 PM", meal: "Milk + dates" }
  ],
  "5km": [
    { time: "6:00 AM", meal: "Banana + dates + coffee" },
    { time: "8:30 AM", meal: "Idli/dosa + sambar + chutney" },
    { time: "11:00 AM", meal: "Mixed nuts + apple" },
    { time: "1:30 PM", meal: "Rice + dal + chicken + mixed veg + curd" },
    { time: "5:00 PM", meal: "Sweet potato + boiled eggs" },
    { time: "8:30 PM", meal: "Roti + palak paneer + salad" },
    { time: "11:00 PM", meal: "Warm milk + turmeric" }
  ]
};

// Utility Functions
const showToast = (message, type = 'success') => {
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  toast.textContent = message;
  document.body.appendChild(toast);
  
  setTimeout(() => {
    toast.remove();
  }, 3000);
};

// Real AI Analysis Function
const analyzeVideoWithAI = async (videoFile, distance, pixelsPerMeter = 100) => {
  const apiUrl = getApiUrl();
  
  try {
    const formData = new FormData();
    formData.append('file', videoFile);
    formData.append('distance', distance.replace('m', ''));
    formData.append('pixels_per_meter', pixelsPerMeter.toString());
    
    const response = await fetch(`${apiUrl}${API_CONFIG.endpoints.analyze}`, {
      method: 'POST',
      body: formData
    });
    
    if (!response.ok) {
      throw new Error(`Analysis failed: ${response.status} ${response.statusText}`);
    }
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Analysis failed');
    }
    
    return {
      distance: result.distance,
      timestamp: result.timestamp,
      timeTaken: `${result.metrics.time_taken_s.toFixed(2)}s`,
      maxSpeed: result.metrics.max_speed_mps.toFixed(2),
      acceleration: result.metrics.acceleration_0_30?.toFixed(1) || 'N/A',
      strideLength: result.metrics.stride_length_m.toFixed(2),
      cadence: result.metrics.cadence_sps.toFixed(1),
      cadenceSpm: Math.round(result.metrics.cadence_spm),
      groundContactTime: Math.round(result.metrics.ground_contact_ms),
      flightTime: Math.round(result.metrics.flight_time_ms),
      kneeDriveAngle: result.metrics.knee_drive_angle?.toFixed(1) || 'N/A',
      torsoLean: result.metrics.torso_lean_deg?.toFixed(1) || 'N/A',
      fatigueIndex: result.metrics.fatigue_index?.toFixed(1) || 'N/A',
      formScore: Math.round(result.metrics.form_score),
      feedback: result.metrics.feedback || [],
      drills: result.metrics.drills || [],
      analyzed: true,
      date: new Date().toISOString()
    };
  } catch (error) {
    console.error('AI Analysis Error:', error);
    throw error;
  }
};

const generateMockAnalysis = (distance) => {
  const ranges = {
    "100m": { time: [11.0, 13.5], speed: [8.5, 10.5], stride: [2.1, 2.5], cadence: [4.3, 5.2], contact: [95, 125] },
    "400m": { time: [48.0, 65.0], speed: [6.5, 8.5], stride: [1.9, 2.3], cadence: [3.6, 4.4], contact: [110, 145] },
    "1km": { time: [170, 230], speed: [5.0, 7.0], stride: [1.7, 2.1], cadence: [3.3, 4.1], contact: [125, 160] },
    "5km": { time: [900, 1300], speed: [4.0, 6.0], stride: [1.5, 2.0], cadence: [3.0, 3.9], contact: [140, 180] }
  };
  
  const range = ranges[distance];
  const timeTaken = (Math.random() * (range.time[1] - range.time[0]) + range.time[0]);
  const maxSpeed = (Math.random() * (range.speed[1] - range.speed[0]) + range.speed[0]);
  const strideLength = (Math.random() * (range.stride[1] - range.stride[0]) + range.stride[0]);
  const cadence = (Math.random() * (range.cadence[1] - range.cadence[0]) + range.cadence[0]);
  const groundContact = (Math.random() * (range.contact[1] - range.contact[0]) + range.contact[0]);
  const formScore = Math.floor(Math.random() * 26) + 70; // 70-95%
  
  const feedbacks = {
    "100m": ["Excellent acceleration phase", "Strong knee drive", "Slight overstride - reduce by 3-5cm", "Good arm rhythm"],
    "400m": ["Good pace distribution", "Strong transition phase", "Minor deceleration in final 100m", "Cadence consistency excellent"],
    "1km": ["Excellent aerobic efficiency", "Consistent stride pattern", "Good energy distribution", "Minor form breakdown in final 200m"],
    "5km": ["Outstanding endurance control", "Excellent stride efficiency", "Good fuel management", "Strong mental focus"]
  };
  
  const drills = {
    "100m": ["A-skips: 3x20m", "Bounding: 4x30m", "Core planks: 3x45s"],
    "400m": ["Tempo runs: 3x300m", "Speed endurance: 4x200m", "Core circuit: 15min"],
    "1km": ["Interval training: 6x400m", "Tempo run: 2km", "Hill repeats: 8x200m"],
    "5km": ["Long intervals: 5x1km", "Tempo runs: 4km", "Hill training: 10x300m"]
  };
  
  const formatTime = (seconds) => {
    if (distance === "100m" || distance === "400m") {
      return `${seconds.toFixed(1)}s`;
    } else if (distance === "1km") {
      const minutes = Math.floor(seconds / 60);
      const secs = (seconds % 60).toFixed(0);
      return `${minutes}:${secs.padStart(2, '0')}`;
    } else {
      const minutes = Math.floor(seconds / 60);
      const secs = (seconds % 60).toFixed(0);
      return `${minutes}:${secs.padStart(2, '0')}`;
    }
  };
  
  return {
    distance,
    timeTaken: formatTime(timeTaken),
    maxSpeed: maxSpeed.toFixed(1),
    strideLength: strideLength.toFixed(2),
    cadence: cadence.toFixed(1),
    groundContactTime: Math.round(groundContact),
    formScore,
    feedback: feedbacks[distance],
    drills: drills[distance],
    analyzed: true,
    date: new Date().toISOString()
  };
};

// Toast Component
const Toast = ({ message, type, onClose }) => {
  useEffect(() => {
    const timer = setTimeout(onClose, 3000);
    return () => clearTimeout(timer);
  }, [onClose]);
  
  return (
    <div className={`toast ${type}`}>
      {message}
    </div>
  );
};

// Backend Status Indicator Component
const BackendStatusIndicator = ({ status }) => {
  const getStatusConfig = () => {
    switch (status) {
      case 'online':
        return { className: 'status--success', text: '🟢 AI Backend Online' };
      case 'offline':
        return { className: 'status--error', text: '🔴 AI Backend Offline - Deploy Required' };
      case 'checking':
        return { className: 'status--warning', text: '🟡 Connecting...' };
      default:
        return { className: 'status--info', text: '⚪ Status Unknown' };
    }
  };
  
  const config = getStatusConfig();
  
  return (
    <div className={`status ${config.className}`} style={{ margin: '16px 0' }}>
      {config.text}
    </div>
  );
};

// Landing Page Component
const LandingPage = ({ onNavigate }) => {
  const { status } = useBackendStatus();
  
  return (
    <div>
      {/* Setup Banner */}
      {status === 'offline' && (
        <div style={{ 
          background: 'var(--color-warning)', 
          color: 'white', 
          padding: '12px 20px', 
          textAlign: 'center',
          fontWeight: 'var(--font-weight-medium)'
        }}>
          ⚙️ Setup Required: Deploy the AI backend first (instructions provided)
        </div>
      )}
      
      {/* Hero Section */}
      <div className="hero-bg" style={{ color: 'white', padding: '80px 20px', textAlign: 'center' }}>
        <div className="container">
          <h1 style={{ fontSize: '48px', marginBottom: '16px', color: 'white' }}>SPRINT.AI</h1>
          <p style={{ fontSize: '20px', marginBottom: '8px', color: 'rgba(255,255,255,0.9)' }}>
            AI-Powered Running Assessment for Indian Athletes
          </p>
          <h2 style={{ fontSize: '32px', marginBottom: '32px', color: 'white', fontWeight: 'normal' }}>
            Upload Your Run. Get AI Feedback. Compete Nationally.
          </h2>
          <div className="hero-buttons">
            <button className="btn btn--primary btn--lg" onClick={() => onNavigate('register')}>
              Register as Athlete
            </button>
            <button className="btn btn--outline btn--lg" onClick={() => onNavigate('login')} style={{ color: 'white', borderColor: 'white' }}>
              Login
            </button>
            <button className="btn btn--secondary btn--lg" onClick={() => onNavigate('admin-login')}>
              Admin Login
            </button>
          </div>
        </div>
      </div>
      
      {/* Features Section */}
      <div className="container" style={{ padding: '80px 20px' }}>
        <div className="feature-grid">
          <div className="feature-card">
            <h3 style={{ marginBottom: '16px' }}>AI Video Analysis</h3>
            <p>Upload your running videos and get detailed biomechanics analysis using advanced AI technology.</p>
          </div>
          <div className="feature-card">
            <h3 style={{ marginBottom: '16px' }}>Personalized Diet &amp; Training</h3>
            <p>Receive customized training plans and diet recommendations based on your running distance.</p>
          </div>
          <div className="feature-card">
            <h3 style={{ marginBottom: '16px' }}>National Leaderboard</h3>
            <p>Compete with athletes across India and track your performance rankings by state and distance.</p>
          </div>
          <div className="feature-card">
            <h3 style={{ marginBottom: '16px' }}>Official Review System</h3>
            <p>Get your performance reviewed by official coaches and earn recognition for outstanding results.</p>
          </div>
        </div>
      </div>
      
      {/* Footer */}
      <footer style={{ textAlign: 'center', padding: '40px 20px', backgroundColor: 'var(--color-surface)', borderTop: '1px solid var(--color-border)' }}>
        <p style={{ margin: 0, color: 'var(--color-text-secondary)' }}>NCC Innovation Project | 2025</p>
      </footer>
    </div>
  );
};

// Registration Component
const Registration = ({ onNavigate }) => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: '',
    age: '',
    gender: '',
    state: '',
    distance: '',
    mobile: ''
  });
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Create Firebase auth account
      const userCredential = await auth.createUserWithEmailAndPassword(formData.email, formData.password);
      const user = userCredential.user;
      
      // Save to Firestore
      await db.collection('athletes').doc(user.uid).set({
        name: formData.name,
        email: formData.email,
        age: parseInt(formData.age),
        gender: formData.gender,
        state: formData.state,
        distance: formData.distance,
        mobile: formData.mobile,
        userType: 'athlete',
        createdAt: new Date(),
        reports: [],
        reviewedCount: 0
      });
      
      showToast('Registration successful!');
      onNavigate('dashboard');
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="container" style={{ maxWidth: '600px', padding: '40px 20px' }}>
      <div className="card">
        <div className="card__header">
          <h2>Register as Athlete</h2>
        </div>
        <div className="card__body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Full Name</label>
              <input 
                type="text" 
                className="form-control" 
                value={formData.name}
                onChange={(e) => setFormData({...formData, name: e.target.value})}
                required 
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Email</label>
              <input 
                type="email" 
                className="form-control" 
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                required 
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Password</label>
              <input 
                type="password" 
                className="form-control" 
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                required 
              />
            </div>
            
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
              <div className="form-group">
                <label className="form-label">Age</label>
                <input 
                  type="number" 
                  className="form-control" 
                  value={formData.age}
                  onChange={(e) => setFormData({...formData, age: e.target.value})}
                  required 
                />
              </div>
              
              <div className="form-group">
                <label className="form-label">Gender</label>
                <select 
                  className="form-control" 
                  value={formData.gender}
                  onChange={(e) => setFormData({...formData, gender: e.target.value})}
                  required
                >
                  <option value="">Select Gender</option>
                  <option value="Male">Male</option>
                  <option value="Female">Female</option>
                </select>
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">State</label>
              <select 
                className="form-control" 
                value={formData.state}
                onChange={(e) => setFormData({...formData, state: e.target.value})}
                required
              >
                <option value="">Select State</option>
                {INDIAN_STATES.map(state => (
                  <option key={state} value={state}>{state}</option>
                ))}
              </select>
            </div>
            
            <div className="form-group">
              <label className="form-label">Running Distance</label>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '8px' }}>
                {DISTANCES.map(distance => (
                  <label key={distance} style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                    <input 
                      type="radio" 
                      name="distance" 
                      value={distance}
                      checked={formData.distance === distance}
                      onChange={(e) => setFormData({...formData, distance: e.target.value})}
                      required
                    />
                    {distance}
                  </label>
                ))}
              </div>
            </div>
            
            <div className="form-group">
              <label className="form-label">Mobile</label>
              <input 
                type="tel" 
                className="form-control" 
                value={formData.mobile}
                onChange={(e) => setFormData({...formData, mobile: e.target.value})}
                required 
              />
            </div>
            
            <button type="submit" className="btn btn--primary btn--full-width" disabled={loading}>
              {loading ? <span className="loading-spinner"></span> : 'Register'}
            </button>
          </form>
          
          <div style={{ textAlign: 'center', marginTop: '16px' }}>
            <a href="#" onClick={() => onNavigate('login')}>Already have an account? Login</a>
          </div>
        </div>
      </div>
    </div>
  );
};

// Login Component
const Login = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      await auth.signInWithEmailAndPassword(email, password);
      showToast('Login successful!');
      onNavigate('dashboard');
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="container" style={{ maxWidth: '400px', padding: '40px 20px' }}>
      <div className="card">
        <div className="card__header">
          <h2>Login</h2>
        </div>
        <div className="card__body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input 
                type="email" 
                className="form-control" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required 
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Password</label>
              <input 
                type="password" 
                className="form-control" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required 
              />
            </div>
            
            <button type="submit" className="btn btn--primary btn--full-width" disabled={loading}>
              {loading ? <span className="loading-spinner"></span> : 'Login'}
            </button>
          </form>
          
          <div style={{ textAlign: 'center', marginTop: '16px' }}>
            <a href="#" onClick={() => onNavigate('register')}>Don't have an account? Register</a>
          </div>
        </div>
      </div>
    </div>
  );
};

// Admin Login Component
const AdminLogin = ({ onNavigate }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (email !== 'buildorburn0@gmail.com' || password !== 'burntobuild') {
      showToast('Invalid admin credentials', 'error');
      return;
    }
    
    setLoading(true);
    
    try {
      // For admin, we'll store in a global variable for simplicity
      window.currentUser = { email, userType: 'admin' };
      showToast('Admin login successful!');
      onNavigate('admin');
    } catch (error) {
      showToast(error.message, 'error');
    } finally {
      setLoading(false);
    }
  };
  
  return (
    <div className="container" style={{ maxWidth: '400px', padding: '40px 20px' }}>
      <div className="card">
        <div className="card__header">
          <h2>Admin Login</h2>
        </div>
        <div className="card__body">
          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Email</label>
              <input 
                type="email" 
                className="form-control" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="buildorburn0@gmail.com"
                required 
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Password</label>
              <input 
                type="password" 
                className="form-control" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="burntobuild"
                required 
              />
            </div>
            
            <button type="submit" className="btn btn--primary btn--full-width" disabled={loading}>
              {loading ? <span className="loading-spinner"></span> : 'Login as Admin'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

// Athlete Dashboard Component
const AthleteDashboard = ({ onNavigate, user, userData }) => {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [reports, setReports] = useState([]);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [leaderboardFilter, setLeaderboardFilter] = useState(userData?.distance || '100m');
  const [leaderboardData, setLeaderboardData] = useState([]);
  const [pixelsPerMeter, setPixelsPerMeter] = useState(100);
  const [uploadProgress, setUploadProgress] = useState(0);
  const { status, apiUrl } = useBackendStatus();
  
  useEffect(() => {
    if (userData?.reports) {
      setReports(userData.reports);
    }
    loadLeaderboard();
  }, [userData, leaderboardFilter]);
  
  const loadLeaderboard = async () => {
    try {
      const snapshot = await db.collection('reports')
        .where('distance', '==', leaderboardFilter)
        .where('reviewed', '==', true)
        .orderBy('timeTaken')
        .limit(20)
        .get();
      
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setLeaderboardData(data);
    } catch (error) {
      console.error('Error loading leaderboard:', error);
    }
  };
  
  const handleVideoUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setUploadedFile(file);
    }
  };
  
  const analyzeVideo = async () => {
    if (!uploadedFile) {
      showToast('Please upload a video first', 'error');
      return;
    }
    
    setAnalyzing(true);
    
    try {
      // Real AI Analysis
      const analysis = await analyzeVideoWithAI(uploadedFile, userData.distance, pixelsPerMeter);
      
      // Save report to Firestore
      const reportRef = await db.collection('reports').add({
        athleteId: user.uid,
        athleteName: userData.name,
        state: userData.state,
        distance: userData.distance,
        uploadDate: new Date(),
        videoUrl: `video_${Date.now()}.mp4`, // Mock URL
        timeTaken: analysis.timeTaken,
        maxSpeed: analysis.maxSpeed,
        strideLength: analysis.strideLength,
        cadence: analysis.cadence,
        groundContactTime: analysis.groundContactTime,
        formScore: analysis.formScore,
        feedback: analysis.feedback,
        drills: analysis.drills,
        reviewed: false
      });
      
      // Add to user's reports
      const newReport = { id: reportRef.id, ...analysis };
      const updatedReports = [...reports, newReport];
      setReports(updatedReports);
      
      // Update user document
      await db.collection('athletes').doc(user.uid).update({
        reports: firebase.firestore.FieldValue.arrayUnion(newReport)
      });
      
      showToast('Video analysis completed!');
      setUploadedFile(null);
      
    } catch (error) {
      showToast('Analysis failed: ' + error.message, 'error');
    } finally {
      setAnalyzing(false);
    }
  };
  
  const handleLogout = async () => {
    try {
      await auth.signOut();
      onNavigate('landing');
    } catch (error) {
      showToast('Logout failed', 'error');
    }
  };
  
  const renderDashboard = () => (
    <div>
      <h2>Welcome, {userData?.name}!</h2>
      <p style={{ color: 'var(--color-text-secondary)', marginBottom: '16px' }}>
        {userData?.distance} Runner from {userData?.state}
      </p>
      
      <BackendStatusIndicator status={status} />
      
      {status === 'offline' && (
        <div className="card" style={{ marginBottom: '32px', backgroundColor: 'var(--color-bg-4)' }}>
          <div className="card__body">
            <h3>⚠️ AI Backend Not Deployed</h3>
            <p>To enable real AI analysis, deploy the backend using the provided files.</p>
            <p>Current API URL: <code>{apiUrl}</code></p>
            <p>Change the API URL in your admin settings once deployed.</p>
          </div>
        </div>
      )}
      
      <div className="dashboard-grid">
        <div className="stats-card">
          <h3>{reports.length}</h3>
          <p>Total Analyses</p>
        </div>
        
        <div className="stats-card">
          <h3>{reports.filter(r => r.formScore >= 80).length}</h3>
          <p>High Performance Runs</p>
        </div>
        
        <div className="stats-card">
          <h3>{userData?.reviewedCount || 0}</h3>
          <p>Reviewed Reports</p>
        </div>
      </div>
      
      {/* Training Plan */}
      <div className="card" style={{ marginTop: '32px' }}>
        <div className="card__header">
          <h3>Weekly Training Plan - {userData?.distance}</h3>
        </div>
        <div className="card__body">
          <table className="table">
            <thead>
              <tr>
                <th>Day</th>
                <th>Warm-up</th>
                <th>Main</th>
                <th>Cool-down</th>
              </tr>
            </thead>
            <tbody>
              {TRAINING_PLANS[userData?.distance]?.map((plan, index) => (
                <tr key={index}>
                  <td>{plan.day}</td>
                  <td>{plan.warmup}</td>
                  <td>{plan.main}</td>
                  <td>{plan.cooldown}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Diet Plan */}
      <div className="card" style={{ marginTop: '32px' }}>
        <div className="card__header">
          <h3>Weekly Diet Plan - {userData?.distance}</h3>
        </div>
        <div className="card__body">
          <table className="table">
            <thead>
              <tr>
                <th>Time</th>
                <th>Meal</th>
              </tr>
            </thead>
            <tbody>
              {DIET_PLANS[userData?.distance]?.map((meal, index) => (
                <tr key={index}>
                  <td>{meal.time}</td>
                  <td>{meal.meal}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
  
  const renderUpload = () => (
    <div>
      <h2>Upload Assessment Video</h2>
      
      <BackendStatusIndicator status={status} />
      
      <div className="card">
        <div className="card__body">
          <div className="form-group">
            <label className="form-label">Distance (Locked to your registration)</label>
            <input 
              type="text" 
              className="form-control" 
              value={userData?.distance}
              disabled
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Calibration (Pixels per Meter)</label>
            <input 
              type="number" 
              className="form-control" 
              value={pixelsPerMeter}
              onChange={(e) => setPixelsPerMeter(parseInt(e.target.value))}
              min="50"
              max="500"
            />
            <small style={{ color: 'var(--color-text-secondary)' }}>
              For accurate measurements, ensure:
              • Video is shot from side view
              • Full running motion is visible
              • Known distance marker is visible (optional but recommended)
              • Video is at least 30 FPS
              • Default calibration: 100 pixels = 1 meter (adjustable)
            </small>
          </div>
          
          <div className="form-group">
            <label className="form-label">Upload Video</label>
            <input 
              type="file" 
              className="form-control" 
              accept=".mp4,.mov,.avi"
              onChange={handleVideoUpload}
            />
            <small style={{ color: 'var(--color-text-secondary)' }}>
              Upload a side view video of your full run (30+ FPS recommended)
            </small>
          </div>
          
          {uploadedFile && (
            <div className="form-group">
              <p><strong>Selected:</strong> {uploadedFile.name} ({(uploadedFile.size / 1024 / 1024).toFixed(1)} MB)</p>
              <video 
                controls 
                style={{ maxWidth: '100%', height: '200px', backgroundColor: 'var(--color-surface)' }}
                src={URL.createObjectURL(uploadedFile)}
              />
            </div>
          )}
          
          <button 
            className="btn btn--primary" 
            onClick={analyzeVideo} 
            disabled={!uploadedFile || analyzing || status === 'offline'}
            title={status === 'offline' ? 'Backend is offline - cannot analyze' : ''}
          >
            {analyzing ? (
              <>
                <span className="loading-spinner" style={{ marginRight: '8px' }}></span>
                Analyzing video with MediaPipe AI... This may take 30-60 seconds
              </>
            ) : (
              'Analyze with AI'
            )}
          </button>
          
          {analyzing && (
            <div style={{ marginTop: '16px', padding: '16px', backgroundColor: 'var(--color-bg-1)', borderRadius: 'var(--radius-base)' }}>
              <p><strong>Processing your video with MediaPipe AI...</strong></p>
              <p>• Uploading video to backend</p>
              <p>• Extracting pose keypoints using MediaPipe BlazePose 3D</p>
              <p>• Calculating biomechanics parameters</p>
              <p>• Generating performance feedback and drills</p>
              <p><em>This may take 30-60 seconds depending on video length...</em></p>
            </div>
          )}
          
          {status === 'offline' && (
            <div className="card" style={{ marginTop: '16px', backgroundColor: 'var(--color-bg-4)' }}>
              <div className="card__body">
                <h4>⚠️ Backend Required</h4>
                <p>To enable real AI analysis, the backend must be deployed and running.</p>
                <p>Please contact your administrator to configure the API endpoint.</p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
  
  const renderReports = () => (
    <div>
      <h2>My Reports</h2>
      
      {reports.length === 0 ? (
        <div className="card">
          <div className="card__body" style={{ textAlign: 'center', padding: '40px' }}>
            <p>No analysis reports yet. Upload your first video to get started!</p>
            <button className="btn btn--primary" onClick={() => setActiveTab('upload')}>Upload Video</button>
          </div>
        </div>
      ) : (
        <div>
          {reports.map((report, index) => (
            <div key={index} className="report-card">
              <h3>SPRINT.AI Analysis Report</h3>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))', gap: '16px', margin: '16px 0' }}>
                <div><strong>Distance:</strong> {report.distance}</div>
                <div><strong>Time Taken:</strong> {report.timeTaken}</div>
                <div><strong>Max Speed:</strong> {report.maxSpeed} m/s</div>
                <div><strong>Stride Length:</strong> {report.strideLength}m</div>
                <div><strong>Cadence:</strong> {report.cadence} steps/sec</div>
                <div><strong>Ground Contact:</strong> {report.groundContactTime}ms</div>
                <div><strong>Form Score:</strong> <span className={`status ${report.formScore >= 80 ? 'status--success' : 'status--warning'}`}>{report.formScore}%</span></div>
              </div>
              
              <div style={{ marginTop: '20px' }}>
                <h4>Feedback:</h4>
                <ul>
                  {report.feedback?.map((fb, i) => <li key={i}>{fb}</li>)}
                </ul>
              </div>
              
              <div style={{ marginTop: '16px' }}>
                <h4>Improvement Drills:</h4>
                <ul>
                  {report.drills?.map((drill, i) => <li key={i}>{drill}</li>)}
                </ul>
              </div>
              
              {report.date && (
                <div style={{ marginTop: '16px', fontSize: '12px', color: 'var(--color-text-secondary)' }}>
                  Analyzed on: {new Date(report.date).toLocaleDateString()}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
  
  const renderLeaderboard = () => (
    <div>
      <h2>Leaderboard</h2>
      
      <div className="leaderboard-filters">
        {DISTANCES.map(distance => (
          <button 
            key={distance}
            className={leaderboardFilter === distance ? 'active' : ''}
            onClick={() => setLeaderboardFilter(distance)}
          >
            {distance}
          </button>
        ))}
      </div>
      
      <div className="card">
        <div className="card__body">
          <p style={{ marginBottom: '16px', color: 'var(--color-text-secondary)' }}>
            Only reviewed reports appear on the leaderboard
          </p>
          
          {leaderboardData.length === 0 ? (
            <p>No reviewed reports for {leaderboardFilter} yet.</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Name</th>
                  <th>State</th>
                  <th>Time</th>
                  <th>AI Score</th>
                </tr>
              </thead>
              <tbody>
                {leaderboardData.map((entry, index) => (
                  <tr key={entry.id} className={entry.athleteId === user?.uid ? 'highlight' : ''}>
                    <td>{index + 1}</td>
                    <td>{entry.athleteName}</td>
                    <td>{entry.state}</td>
                    <td>{entry.timeTaken}</td>
                    <td>
                      <span className={`status ${entry.formScore >= 80 ? 'status--success' : 'status--warning'}`}>
                        {entry.formScore}%
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  );
  
  return (
    <div className="dashboard-layout">
      {/* Sidebar */}
      <div className="sidebar">
        <h2 style={{ marginBottom: '24px' }}>SPRINT.AI</h2>
        <ul className="sidebar-nav">
          <li>
            <button 
              className={activeTab === 'dashboard' ? 'active' : ''}
              onClick={() => setActiveTab('dashboard')}
            >
              Dashboard
            </button>
          </li>
          <li>
            <button 
              className={activeTab === 'upload' ? 'active' : ''}
              onClick={() => setActiveTab('upload')}
            >
              Upload Video
            </button>
          </li>
          <li>
            <button 
              className={activeTab === 'reports' ? 'active' : ''}
              onClick={() => setActiveTab('reports')}
            >
              My Reports
            </button>
          </li>
          <li>
            <button 
              className={activeTab === 'leaderboard' ? 'active' : ''}
              onClick={() => setActiveTab('leaderboard')}
            >
              Leaderboard
            </button>
          </li>
          <li>
            <button onClick={handleLogout} style={{ color: 'var(--color-error)' }}>
              Logout
            </button>
          </li>
        </ul>
      </div>
      
      {/* Main Content */}
      <div className="main-content">
        {activeTab === 'dashboard' && renderDashboard()}
        {activeTab === 'upload' && renderUpload()}
        {activeTab === 'reports' && renderReports()}
        {activeTab === 'leaderboard' && renderLeaderboard()}
      </div>
    </div>
  );
};

// Admin Dashboard Component
const AdminDashboard = ({ onNavigate }) => {
  const [activeTab, setActiveTab] = useState('overview');
  const [athletes, setAthletes] = useState([]);
  const [reports, setReports] = useState([]);
  const [stats, setStats] = useState({ totalAthletes: 0, totalReports: 0, statesCovered: 0, pendingReviews: 0 });
  const [leaderboardFilter, setLeaderboardFilter] = useState('100m');
  const [searchTerm, setSearchTerm] = useState('');
  const { status, apiUrl, updateApiUrl, checkStatus } = useBackendStatus();
  const [newApiUrl, setNewApiUrl] = useState(apiUrl);
  
  useEffect(() => {
    loadAdminData();
  }, []);
  
  const loadAdminData = async () => {
    try {
      // Load athletes
      const athletesSnapshot = await db.collection('athletes').get();
      const athletesData = athletesSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setAthletes(athletesData);
      
      // Load reports
      const reportsSnapshot = await db.collection('reports').get();
      const reportsData = reportsSnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setReports(reportsData);
      
      // Calculate stats
      const uniqueStates = new Set(athletesData.map(a => a.state)).size;
      const pendingReports = reportsData.filter(r => !r.reviewed).length;
      
      setStats({
        totalAthletes: athletesData.length,
        totalReports: reportsData.length,
        statesCovered: uniqueStates,
        pendingReviews: pendingReports
      });
    } catch (error) {
      showToast('Error loading admin data', 'error');
    }
  };
  
  const reviewReport = async (reportId) => {
    try {
      // Update report as reviewed
      await db.collection('reports').doc(reportId).update({ reviewed: true });
      
      // Update local state
      setReports(reports.map(r => r.id === reportId ? { ...r, reviewed: true } : r));
      
      // Find the athlete and increment their reviewedCount
      const report = reports.find(r => r.id === reportId);
      if (report) {
        await db.collection('athletes').doc(report.athleteId).update({
          reviewedCount: firebase.firestore.FieldValue.increment(1)
        });
      }
      
      showToast('Report reviewed successfully!');
      loadAdminData(); // Refresh data
    } catch (error) {
      showToast('Error reviewing report', 'error');
    }
  };
  
  const handleLogout = () => {
    window.currentUser = null;
    onNavigate('landing');
  };
  
  const renderSettings = () => (
    <div>
      <h2>Settings</h2>
      
      <div className="card">
        <div className="card__header">
          <h3>API Backend Configuration</h3>
        </div>
        <div className="card__body">
          <div className="form-group">
            <label className="form-label">Backend API URL</label>
            <input 
              type="url" 
              className="form-control" 
              value={newApiUrl}
              onChange={(e) => setNewApiUrl(e.target.value)}
              placeholder="https://sprint-ai-api.onrender.com"
            />
            <small style={{ color: 'var(--color-text-secondary)' }}>
              Enter the deployed backend URL (e.g., https://your-app.onrender.com)
            </small>
          </div>
          
          <div style={{ display: 'flex', gap: '16px', alignItems: 'center' }}>
            <button 
              className="btn btn--primary" 
              onClick={() => updateApiUrl(newApiUrl)}
            >
              Save API URL
            </button>
            
            <button 
              className="btn btn--outline" 
              onClick={checkStatus}
            >
              Test Connection
            </button>
            
            <BackendStatusIndicator status={status} />
          </div>
          
          <div style={{ marginTop: '24px', padding: '16px', backgroundColor: 'var(--color-bg-2)', borderRadius: 'var(--radius-base)' }}>
            <h4>Backend Deployment Instructions:</h4>
            <ol>
              <li>Deploy the FastAPI backend to Render.com or similar service</li>
              <li>Ensure the /analyze and /health endpoints are working</li>
              <li>Update the API URL above with your deployed backend URL</li>
              <li>Test the connection to verify everything is working</li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
  
  const renderOverview = () => (
    <div>
      <h2>Admin Overview</h2>
      
      <BackendStatusIndicator status={status} />
      
      <div className="dashboard-grid">
        <div className="stats-card">
          <h3>{stats.totalAthletes}</h3>
          <p>Total Athletes</p>
        </div>
        
        <div className="stats-card">
          <h3>{stats.totalReports}</h3>
          <p>Videos Analyzed</p>
        </div>
        
        <div className="stats-card">
          <h3>{stats.statesCovered}</h3>
          <p>States Covered</p>
        </div>
        
        <div className="stats-card">
          <h3>{stats.pendingReviews}</h3>
          <p>Pending Reviews</p>
        </div>
      </div>
    </div>
  );
  
  const renderLeaderboard = () => {
    const filteredReports = reports
      .filter(r => r.distance === leaderboardFilter && r.reviewed)
      .sort((a, b) => parseFloat(a.timeTaken) - parseFloat(b.timeTaken))
      .slice(0, 20);
    
    return (
      <div>
        <h2>Leaderboard Management</h2>
        
        <div className="leaderboard-filters">
          {DISTANCES.map(distance => (
            <button 
              key={distance}
              className={leaderboardFilter === distance ? 'active' : ''}
              onClick={() => setLeaderboardFilter(distance)}
            >
              {distance}
            </button>
          ))}
        </div>
        
        <div className="card">
          <div className="card__body">
            <table className="table">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Name</th>
                  <th>State</th>
                  <th>Time</th>
                  <th>AI Score</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredReports.map((report, index) => (
                  <tr key={report.id}>
                    <td>{index + 1}</td>
                    <td>{report.athleteName}</td>
                    <td>{report.state}</td>
                    <td>{report.timeTaken}</td>
                    <td>
                      <span className={`status ${report.formScore >= 80 ? 'status--success' : 'status--warning'}`}>
                        {report.formScore}%
                      </span>
                    </td>
                    <td>
                      <button className="btn btn--sm btn--outline">View Report</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };
  
  const renderAthletes = () => {
    const filteredAthletes = athletes.filter(athlete => 
      athlete.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      athlete.state.toLowerCase().includes(searchTerm.toLowerCase())
    );
    
    return (
      <div>
        <h2>Athletes Directory</h2>
        
        <div style={{ marginBottom: '20px' }}>
          <input 
            type="text" 
            className="form-control" 
            placeholder="Search by name or state..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        
        <div className="card">
          <div className="card__body">
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>State</th>
                  <th>Distance</th>
                  <th>Reports</th>
                  <th>Reviewed</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredAthletes.map(athlete => (
                  <tr key={athlete.id}>
                    <td>{athlete.name}</td>
                    <td>{athlete.state}</td>
                    <td>{athlete.distance}</td>
                    <td>{athlete.reports?.length || 0}</td>
                    <td>{athlete.reviewedCount || 0}</td>
                    <td>
                      <button className="btn btn--sm btn--outline">View Profile</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    );
  };
  
  const renderAnalytics = () => {
    const stateParticipation = {};
    athletes.forEach(athlete => {
      stateParticipation[athlete.state] = (stateParticipation[athlete.state] || 0) + 1;
    });
    
    useEffect(() => {
      // State-wise Participation Pie Chart
      const ctx1 = document.getElementById('stateChart');
      if (ctx1) {
        new Chart(ctx1, {
          type: 'pie',
          data: {
            labels: Object.keys(stateParticipation).slice(0, 10),
            datasets: [{
              data: Object.values(stateParticipation).slice(0, 10),
              backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5', '#5D878F', '#DB4545', '#D2BA4C', '#964325', '#944454', '#13343B']
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: true,
                text: 'State-wise Participation'
              }
            }
          }
        });
      }
      
      // Top Performers by Distance Bar Chart
      const ctx2 = document.getElementById('performersChart');
      if (ctx2) {
        const distanceCounts = {};
        DISTANCES.forEach(d => {
          distanceCounts[d] = athletes.filter(a => a.distance === d).length;
        });
        
        new Chart(ctx2, {
          type: 'bar',
          data: {
            labels: DISTANCES,
            datasets: [{
              label: 'Athletes',
              data: Object.values(distanceCounts),
              backgroundColor: ['#1FB8CD', '#FFC185', '#B4413C', '#ECEBD5']
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
              title: {
                display: true,
                text: 'Athletes by Distance'
              }
            }
          }
        });
      }
    }, []);
    
    return (
      <div>
        <h2>Analytics</h2>
        
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '32px' }}>
          <div className="card">
            <div className="card__body">
              <div className="chart-container">
                <canvas id="stateChart"></canvas>
              </div>
            </div>
          </div>
          
          <div className="card">
            <div className="card__body">
              <div className="chart-container">
                <canvas id="performersChart"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  };
  
  const renderReviewQueue = () => {
    const pendingReports = reports.filter(r => !r.reviewed);
    
    return (
      <div>
        <h2>Review Queue</h2>
        
        {pendingReports.length === 0 ? (
          <div className="card">
            <div className="card__body" style={{ textAlign: 'center', padding: '40px' }}>
              <p>No pending reports to review.</p>
            </div>
          </div>
        ) : (
          <div className="card">
            <div className="card__body">
              <table className="table">
                <thead>
                  <tr>
                    <th>Athlete</th>
                    <th>Distance</th>
                    <th>Upload Date</th>
                    <th>Time</th>
                    <th>Score</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pendingReports.map(report => (
                    <tr key={report.id}>
                      <td>{report.athleteName}</td>
                      <td>{report.distance}</td>
                      <td>{report.uploadDate?.toDate().toLocaleDateString()}</td>
                      <td>{report.timeTaken}</td>
                      <td>
                        <span className={`status ${report.formScore >= 80 ? 'status--success' : 'status--warning'}`}>
                          {report.formScore}%
                        </span>
                      </td>
                      <td>
                        <button 
                          className="btn btn--sm btn--primary"
                          onClick={() => reviewReport(report.id)}
                        >
                          Review
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    );
  };
  
  return (
    <div style={{ padding: '20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '32px' }}>
        <h1>SPRINT.AI Admin Panel</h1>
        <button className="btn btn--outline" onClick={handleLogout}>Logout</button>
      </div>
      
      <div className="admin-tabs">
        <button className={`admin-tab ${activeTab === 'overview' ? 'active' : ''}`} onClick={() => setActiveTab('overview')}>Overview</button>
        <button className={`admin-tab ${activeTab === 'leaderboard' ? 'active' : ''}`} onClick={() => setActiveTab('leaderboard')}>Leaderboard</button>
        <button className={`admin-tab ${activeTab === 'athletes' ? 'active' : ''}`} onClick={() => setActiveTab('athletes')}>Athletes</button>
        <button className={`admin-tab ${activeTab === 'analytics' ? 'active' : ''}`} onClick={() => setActiveTab('analytics')}>Analytics</button>
        <button className={`admin-tab ${activeTab === 'review' ? 'active' : ''}`} onClick={() => setActiveTab('review')}>Review Queue</button>
        <button className={`admin-tab ${activeTab === 'settings' ? 'active' : ''}`} onClick={() => setActiveTab('settings')}>Settings</button>
      </div>
      
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'leaderboard' && renderLeaderboard()}
      {activeTab === 'athletes' && renderAthletes()}
      {activeTab === 'analytics' && renderAnalytics()}
      {activeTab === 'review' && renderReviewQueue()}
      {activeTab === 'settings' && renderSettings()}
    </div>
  );
};

// Main App Component
const App = () => {
  const [currentPage, setCurrentPage] = useState('landing');
  const [user, setUser] = useState(null);
  const [userData, setUserData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState(null);
  
  useEffect(() => {
    // Listen for auth state changes
    const unsubscribe = auth.onAuthStateChanged(async (user) => {
      if (user) {
        setUser(user);
        
        // Load user data from Firestore
        try {
          const doc = await db.collection('athletes').doc(user.uid).get();
          if (doc.exists) {
            setUserData(doc.data());
            setCurrentPage('dashboard');
          }
        } catch (error) {
          console.error('Error loading user data:', error);
        }
      } else {
        setUser(null);
        setUserData(null);
      }
      setLoading(false);
    });
    
    return () => unsubscribe();
  }, []);
  
  const navigate = (page) => {
    setCurrentPage(page);
  };
  
  if (loading) {
    return (
      <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh' }}>
        <div className="loading-spinner"></div>
      </div>
    );
  }
  
  // Check for admin user
  const isAdmin = window.currentUser?.userType === 'admin';
  
  return (
    <div>
      {currentPage === 'landing' && <LandingPage onNavigate={navigate} />}
      {currentPage === 'register' && <Registration onNavigate={navigate} />}
      {currentPage === 'login' && <Login onNavigate={navigate} />}
      {currentPage === 'admin-login' && <AdminLogin onNavigate={navigate} />}
      {currentPage === 'dashboard' && !isAdmin && <AthleteDashboard onNavigate={navigate} user={user} userData={userData} />}
      {currentPage === 'admin' && <AdminDashboard onNavigate={navigate} />}
      
      {toast && <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />}
    </div>
  );
};

// Render the app
ReactDOM.render(<App />, document.getElementById('root'));